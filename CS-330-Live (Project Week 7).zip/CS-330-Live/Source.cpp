#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "camera.h"
#include "shader.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"




using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "6-5 lighting scene"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 1600;
    const int WINDOW_HEIGHT = 1200;


    bool projToggle = true;

    float rot = -0.5;

    // texture

    unsigned int texture1;
    // camera
    Camera camera(glm::vec3(0.0f, 5.0f, 10.0f));
    float lastX = WINDOW_WIDTH / 2.0f;
    float lastY = WINDOW_HEIGHT / 2.0f;
    bool firstMouse = true;

    // timing
    float deltaTime = 0.0f;
    float lastFrame = 0.0f;

    // lighting
    glm::vec3 lightPos(-5.0f, 3.0f, 4.0f);
    float x = -3.0f;
    float y = 0.0f;
    float z = 7.0f;

    // moving sphere
    float spx = 0.0f;
    float spz = 3.0f;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbo;     // Handles for the vertex buffer objects

        GLuint vao2;         // Handle for the vertex array object
        GLuint vbo2;     // Handles for the vertex buffer objects
        GLuint vao3;         // Handle for the vertex array object
        GLuint vbo3;     // Handles for the vertex buffer objects
        GLuint vao4;         // Handle for the vertex array object
        GLuint vbo4;     // Handles for the vertex buffer objects

        GLuint nVertices;    // Number of indices of the mesh
        GLuint nVertices2;    // Number of indices of the mesh
        GLuint nVertices3;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    // Texture id
    GLuint gTextureId;
    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;
    // Shader program
    GLuint gProgramId;
}

enum {
    ATTRIB_VERTEX,
    ATTRIB_COLOR,
    ATTRIB_NORMAL,
    NUM_ATTRIBS
};


typedef struct
{
    float x;
    float y;
    float z;
    float nx;
    float ny;
    float nz;
    float u;
    float v;
    float r;
    float g;
    float b;
    float a;
    GLbyte padding[16];
} Vertex;

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
// texture
void flipImageVertically(unsigned char* image, int width, int height, int channels);
unsigned int loadTexture(const char* path);
void UDestroyTexture(GLuint textureId);


///* Vertex Shader Source Code*/
//const GLchar* vertexShaderSource = GLSL(440,
//    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
//layout(location = 1) in vec4 color;  // Color data from Vertex Attrib Pointer 1
//
//out vec4 vertexColor; // variable to transfer color data to the fragment shader
////Global variables for the  transform matrices
//uniform mat4 model;
//uniform mat4 view;
//uniform mat4 projection;

//void main()
//{
//    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
//    vertexColor = color; // references incoming color data
//}
//);



///* Vertex Shader Source Code*/
//const GLchar* vertexShaderSource = GLSL(440,
//    layout(location = 0) in vec3 position;
//layout(location = 2) in vec2 textureCoordinate;
//
//out vec2 vertexTextureCoordinate;
//
//
////Global variables for the transform matrices
//uniform mat4 model;
//uniform mat4 view;
//uniform mat4 projection;
//void main()
//{
//    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
//    vertexTextureCoordinate = textureCoordinate;
//}
//);
//
//
///* Fragment Shader Source Code*/
//const GLchar* fragmentShaderSource = GLSL(440,
//    in vec2 vertexTextureCoordinate;
//
//out vec4 fragmentColor;
//
//uniform sampler2D uTexture;
//uniform vec2 uvScale;
//
//void main()
//{
//    fragmentColor = texture(uTexture, vertexTextureCoordinate * uvScale);
//}
//);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}



///* Fragment Shader Source Code*/
//const GLchar* fragmentShaderSource = GLSL(440,
//    in vec4 vertexColor; // Variable to hold incoming color data from vertex shader
//
//out vec4 fragmentColor;
//
//void main()
//{
//    fragmentColor = vec4(vertexColor);
//}
//);



int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

         // Enable z-depth
        glEnable(GL_DEPTH_TEST);

    // build and compile our shader zprogram
    // ------------------------------------
    Shader lightingShader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // //Create the shader program
    //if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
    //    return EXIT_FAILURE;

    //// Load texture (relative to project's directory)
    //const char* texFilename = "//apporto.com/dfs/SNHU/Users/michael.divis_snhu/Desktop/330/CS-330-master/module05/smiley.png";
    //if (!UCreateTexture(texFilename, gTextureId))
    //{
    //    cout << "Failed to load texture " << texFilename << endl;
    //    return EXIT_FAILURE;
    //}
    //// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    //glUseProgram(gProgramId);
    //// We set the texture as texture unit 0
    //glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);


    unsigned int diffuseMap = loadTexture("//apporto.com/dfs/SNHU/Users/michael.divis_snhu/Desktop/330/CS-330-Live/CS-330-Live/images/roof.jpg");
    unsigned int diffuseMap2 = loadTexture("//apporto.com/dfs/SNHU/Users/michael.divis_snhu/Desktop/330/CS-330-Live/CS-330-Live/images/wall.jpg");
    unsigned int diffuseMap3= loadTexture("//apporto.com/dfs/SNHU/Users/michael.divis_snhu/Desktop/330/CS-330-Live/CS-330-Live/images/grass.jpg");
    unsigned int diffuseMap4 = loadTexture("//apporto.com/dfs/SNHU/Users/michael.divis_snhu/Desktop/330/CS-330-Live/CS-330-Live/images/ball.jpg");
    unsigned int diffuseMap5 = loadTexture("//apporto.com/dfs/SNHU/Users/michael.divis_snhu/Desktop/330/CS-330-Live/CS-330-Live/images/box.png");

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // shader configuration
    // --------------------
    lightingShader.use();
    lightingShader.setInt("material.diffuse", 0);
    lightingShader.setInt("material.specular", 1);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
        

        // input
        // -----
        UProcessInput(gWindow);



        // Clear the frame and z buffers
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


        // be sure to activate shader when setting uniforms/drawing objects
        lightingShader.use();
        lightingShader.setVec3("viewPos", camera.Position);
        lightingShader.setFloat("material.shininess", 32.0f);


        /*
           Here we set all the uniforms for the 5/6 types of lights we have. We have to set them manually and index
           the proper PointLight struct in the array to set each uniform variable. This can be done more code-friendly
           by defining light types as classes and set their values in there, or by using a more efficient uniform approach
           by using 'Uniform buffer objects', but that is something we'll discuss in the 'Advanced GLSL' tutorial.
        */

        // positions of the point lights
        glm::vec3 pointLightPositions[] = {
            glm::vec3(x, y, z),

        };

      
        // directional light
        lightingShader.setVec3("dirLight.direction", -0.2f, -1.0f, -0.3f);
        lightingShader.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
        lightingShader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
        // point light 1
        lightingShader.setVec3("pointLights[0].position", pointLightPositions[0]);
        lightingShader.setVec3("pointLights[0].ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[0].diffuse", 0.8f, 0.8f, 0.8f);
        lightingShader.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("pointLights[0].constant", 1.0f);
        lightingShader.setFloat("pointLights[0].linear", 0.09);
        lightingShader.setFloat("pointLights[0].quadratic", 0.032);
        // point light 2
        lightingShader.setVec3("pointLights[1].position", pointLightPositions[0]);
        lightingShader.setVec3("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[1].diffuse", 0.8f, 0.8f, 0.8f);
        lightingShader.setVec3("pointLights[1].specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("pointLights[1].constant", 1.0f);
        lightingShader.setFloat("pointLights[1].linear", 0.09);
        lightingShader.setFloat("pointLights[1].quadratic", 0.032);
        // point light 3
        lightingShader.setVec3("pointLights[2].position", pointLightPositions[0]);
        lightingShader.setVec3("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[2].diffuse", 0.8f, 0.8f, 0.8f);
        lightingShader.setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("pointLights[2].constant", 1.0f);
        lightingShader.setFloat("pointLights[2].linear", 0.09);
        lightingShader.setFloat("pointLights[2].quadratic", 0.032);
        // point light 4
        lightingShader.setVec3("pointLights[3].position", pointLightPositions[0]);
        lightingShader.setVec3("pointLights[3].ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[3].diffuse", 0.8f, 0.8f, 0.8f);
        lightingShader.setVec3("pointLights[3].specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("pointLights[3].constant", 1.0f);
        lightingShader.setFloat("pointLights[3].linear", 0.09);
        lightingShader.setFloat("pointLights[3].quadratic", 0.032);
        // spotLight
        lightingShader.setVec3("spotLight.position", camera.Position);
        lightingShader.setVec3("spotLight.direction", camera.Front);
        lightingShader.setVec3("spotLight.ambient", 0.0f, 0.0f, 0.05f);
        lightingShader.setVec3("spotLight.diffuse", 0.0f, 0.0f, 0.8f);
        lightingShader.setVec3("spotLight.specular", 0.0f, 0.0f, 1.0f);
        lightingShader.setFloat("spotLight.constant", 1.0f);
        lightingShader.setFloat("spotLight.linear", 0.09);
        lightingShader.setFloat("spotLight.quadratic", 0.032);
        lightingShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
        lightingShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

        if (projToggle) {
            // view/projection transformations
            glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
            glm::mat4 view = camera.GetViewMatrix();
            lightingShader.setMat4("projection", projection);
            lightingShader.setMat4("view", view);

            // world transformation
            glm::mat4 model = glm::mat4(1.0f);
            lightingShader.setMat4("model", model);


            // positions of
            glm::vec3 pyramidPos[] = {
                glm::vec3(0.0f,  1.5f,  2.0f),

            };
            // positions of 
            glm::vec3 cubePos[] = {
                glm::vec3(0.7f,  0.2f,  2.0f),

            };
            // positions of
            glm::vec3 planePos[] = {
                glm::vec3(0.0f,  -0.5f,  0.0f),

            };

            // positions all containers
            glm::vec3 spherePositions[] = {
                glm::vec3(2.5, 0.3f, 3.0),

            };









            // pyramid
            // Activate the VBOs contained within the mesh's VAO
            glBindVertexArray(gMesh.vao);

            // bind textures on corresponding texture units
                // bind diffuse map
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap);



            // calculate the model matrix for each object and pass it to shader before drawing

            float angle = 0.0f;
            //model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
            lightingShader.setMat4("model", model);

            // Draws the triangles
            glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);





            // cube
             // Activate the VBOs contained within the mesh's VAO
            glBindVertexArray(gMesh.vao2);

            // bind textures on corresponding texture units
                // bind diffuse map
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap2);

            // calculate the model matrix for each object and pass it to shader before drawing


            //model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.0f, 0.5f));
            lightingShader.setMat4("model", model);

            // Draws the triangles
            glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices2);






            // plane
             // Activate the VBOs contained within the mesh's VAO
            glBindVertexArray(gMesh.vao3);

            // bind textures on corresponding texture units
                // bind diffuse map
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap3);

            // calculate the model matrix for each object and pass it to shader before drawing
            model = glm::translate(model, planePos[0]);

            //model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
            lightingShader.setMat4("model", model);

            // Draws the triangles
            glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices3);



            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap4);
            // sphere
            glBindVertexArray(gMesh.vao4);


            // calculate the model matrix for each object and pass it to shader before drawing

            model = glm::translate(model, spherePositions[0]);
            model = glm::rotate(model, glm::radians(angle), glm::vec3(sin(rot), cos(rot), cos(rot)));
            model = glm::scale(model, glm::vec3(0.1f)); // Make it a smaller sphere
            lightingShader.setMat4("model", model);

            glDrawArrays(GL_TRIANGLE_STRIP, 0, 128 * 256 * 6);






            // cube
            // Activate the VBOs contained within the mesh's VAO
            glBindVertexArray(gMesh.vao2);

            // bind textures on corresponding texture units
                // bind diffuse map
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap5);

            // calculate the model matrix for each object and pass it to shader before drawing
            model = glm::translate(model, glm::vec3(-30.5,-2.5f, 5.0));

            //model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.0f, 0.5f));
            lightingShader.setMat4("model", model);

            // Draws the triangles
            glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices2);







            // Deactivate the Vertex Array Object
            glBindVertexArray(0);

            // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)

            glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.

        


            // Render this frame
            //URender();

            glfwPollEvents();
        }
        else {
            // view/projection transformations
            glm::mat4 projection = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, 0.1f, 100.0f);
            glm::mat4 view = camera.GetViewMatrix();
            lightingShader.setMat4("projection", projection);
            lightingShader.setMat4("view", view);

            // world transformation
            glm::mat4 model = glm::mat4(1.0f);
            lightingShader.setMat4("model", model);


            // positions of
            glm::vec3 pyramidPos[] = {
                glm::vec3(0.0f,  1.5f,  2.0f),

            };
            // positions of 
            glm::vec3 cubePos[] = {
                glm::vec3(0.7f,  0.2f,  2.0f),

            };
            // positions of
            glm::vec3 planePos[] = {
                glm::vec3(0.0f,  -0.5f,  0.0f),

            };

            // positions all containers
            glm::vec3 spherePositions[] = {
                glm::vec3(2.5, 0.3f, 3.0),
      

            };









            // pyramid
            // Activate the VBOs contained within the mesh's VAO
            glBindVertexArray(gMesh.vao);

            // bind textures on corresponding texture units
                // bind diffuse map
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap);



            // calculate the model matrix for each object and pass it to shader before drawing

            float angle = 0.0f;
            //model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
            lightingShader.setMat4("model", model);

            // Draws the triangles
            glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);





            // cube
             // Activate the VBOs contained within the mesh's VAO
            glBindVertexArray(gMesh.vao2);

            // bind textures on corresponding texture units
                // bind diffuse map
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap2);

            // calculate the model matrix for each object and pass it to shader before drawing


            //model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.0f, 0.5f));
            lightingShader.setMat4("model", model);

            // Draws the triangles
            glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices2);





            // plane
             // Activate the VBOs contained within the mesh's VAO
            glBindVertexArray(gMesh.vao3);

            // bind textures on corresponding texture units
                // bind diffuse map
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap3);

            // calculate the model matrix for each object and pass it to shader before drawing
            model = glm::translate(model, planePos[0]);

            //model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
            lightingShader.setMat4("model", model);

            // Draws the triangles
            glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices3);



            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diffuseMap4);
            // sphere
            glBindVertexArray(gMesh.vao4);


            // calculate the model matrix for each object and pass it to shader before drawing

            model = glm::translate(model, spherePositions[0]);
            model = glm::translate(model, spherePositions[1]);
            model = glm::rotate(model, glm::radians(angle), glm::vec3(sin(rot), cos(rot), cos(rot)));
            model = glm::scale(model, glm::vec3(0.1f)); // Make it a smaller sphere
            lightingShader.setMat4("model", model);

            glDrawArrays(GL_TRIANGLE_STRIP, 0, 128 * 256 * 6);

            // Deactivate the Vertex Array Object
            glBindVertexArray(0);

            // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)

            glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.




            // Render this frame
            //URender();

            glfwPollEvents();
        }
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureId);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, mouse_callback);
    glfwSetScrollCallback(*window, scroll_callback);

    //// tell GLFW to capture our mouse
    //glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;



    // glad: load all OpenGL function pointers
    // ---------------------------------------
   /* if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }*/

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);


    // added more movement
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
        camera.ProcessKeyboard(FORWARD, deltaTime);
        std::cout << "W Pressed." << std::endl;
    }

    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        camera.ProcessKeyboard(DOWN, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        camera.ProcessKeyboard(UP, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        if (projToggle)
            projToggle = false;
        else
            projToggle = true;


    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        camera.ProcessKeyboard(YAW_U, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        camera.ProcessKeyboard(YAW_D, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        camera.ProcessKeyboard(PITCH_R, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        camera.ProcessKeyboard(PITCH_L, deltaTime);

    if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS)
        x += .1;
    if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS)
        x -= .1;
    if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS)
        y += .1;
    if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS)
        y -= .1;
    if (glfwGetKey(window, GLFW_KEY_5) == GLFW_PRESS)
        z += .1;
    if (glfwGetKey(window, GLFW_KEY_6) == GLFW_PRESS)
        z -= .1;

}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// Functioned called to render a frame
void URender()
{  

    //// 1. Scales the object by 2
    //glm::mat4 scale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    //// 2. Rotates shape by 15 degrees in the x axis
    //glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    //// 3. Place object at the origin
    //glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    //// Model matrix: transformations are applied right-to-left order
    //glm::mat4 model = translation * rotation * scale;

    //// camera/view transformation
    //glm::mat4 view = camera.GetViewMatrix();

    //// Creates a perspective projection
    //glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    

}
// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{

    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset / 25, yoffset / 25, 0);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(yoffset);
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    // // Position and Color data
    //GLfloat verts[] = {
    //    // Vertex Positions    // Colors (r,g,b,a)
    //     0.5f,  0.5f, 0.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 0
    //     0.5f, -0.5f, 0.0f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 1
    //    -0.5f, -0.5f, 0.0f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 2
    //    -0.5f,  0.5f, 0.0f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 3

    //     0.5f, -0.5f, -1.0f,  0.5f, 0.5f, 1.0f, 1.0f, // 4 br  right
    //     0.5f,  0.5f, -1.0f,  1.0f, 1.0f, 0.5f, 1.0f, //  5 tl  right
    //    -0.5f,  0.5f, -1.0f,  0.2f, 0.2f, 0.5f, 1.0f, //  6 tl  top
    //    -0.5f, -0.5f, -1.0f,  1.0f, 0.0f, 1.0f, 1.0f  //  7 bl back
    //};

//
    GLfloat verts[] = {
        // Vertex Positions    // Colors (r,g,b,a)       // text coords
        // front face
          0.0f,  3.5f, 0.0f,  0.0f,  0.0f, 1.0f,    0.0f, 1.0f,// Top center Vertex 0
          2.0f, 2.0f, 2.0f,  0.0f,  0.0f, 1.0f,   1.0f, 0.0f,// Bottom front Right Vertex 1
         -2.0f, 2.0f, 2.0f,  0.0f,  0.0f, 1.0f,  -1.0f, 0.0f,// Bottom front Left Vertex 2
        // rear face
          0.0f,  3.5f, 0.0f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,// Top center Vertex 3
          2.0f, 2.0f, -2.0f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,// 4 bottom back right
          -2.0f, 2.0f, -2.0f, 0.0f,  0.0f, -1.0f, -1.0f, 0.0f,// 4 bottom back left
    // right face
          0.0f,  3.5f, 0.0f,  -1.0f,  0.0f, 0.0f, 0.0f, 1.0f,// Top center Vertex 3
          2.0f, 2.0f, -2.0f, -1.0f,  0.0f, 0.0f,   1.0f, 0.0f,// 4 bottom back right
          2.0f, 2.0f, 2.0f,  -1.0f,  0.0f, 0.0f,  -1.0f, 0.0f,// Bottom front Right
    // left face
          0.0f,  3.5f, 0.0f,  1.0f,  0.0f, 0.0f, 0.0f, 1.0f,// Top center Vertex 3
          -2.0f, 2.0f, -2.0f, 1.0f,  0.0f, 0.0f, -1.0f, 0.0f,// 4 bottom back left
          -2.0f, 2.0f, 2.0f,   1.0f,  0.0f, 0.0f,  1.0f, 0.0f,// Bottom front Left


    // bottom

               -2.0f, 2.0f, -2.0f,  0.0f,  -1.0f, 0.0f,  0.0f,  1.0f,
                2.0f, 2.0f, -2.0f, 0.0f,  -1.0f, 0.0f,  1.0f,  1.0f,
                2.0f, 2.0f,  2.0f, 0.0f,  -1.0f, 0.0f,  1.0f,  0.0f,
                2.0f, 2.0f,  2.0f, 0.0f,  -1.0f, 0.0f,  1.0f,  0.0f,
               -2.0f, 2.0f,  2.0f, 0.0f,  -1.0f, 0.0f,  0.0f,  0.0f,
               -2.0f, 2.0f, -2.0f, 0.0f,  -1.0f, 0.0f,   0.0f,  1.0f,
               -2.0f, 2.0f,  2.0f,  0.0f,  -1.0f, 0.0f,  1.0f, 0.0f,// Bottom front Left

    };

    GLfloat verts2[] = {
        -1.5f, -0.5f, -.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
         1.5f, -0.5f, -1.5f,  0.0f,  0.0f, -1.0f,  1.0f,  0.0f,
         1.5f,  2.0f, -1.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
         1.5f,  2.0f, -1.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
        -1.5f,  2.0f, -1.5f,  0.0f,  0.0f, -1.0f,  0.0f,  1.0f,
        -1.5f, -0.5f, -1.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,

        -1.5f, -0.5f,  1.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
         1.5f, -0.5f,  1.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
         1.5f,  2.0f,  1.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
         1.5f,  2.0f,  1.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
        -1.5f,  2.0f,  1.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
        -1.5f, -0.5f,  1.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

        -1.5f,  2.0f,  1.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -1.5f,  2.0f, -1.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
        -1.5f, -0.5f, -1.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
        -1.5f, -0.5f, -1.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
        -1.5f, -0.5f,  1.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
        -1.5f,  2.0f,  1.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,

         1.5f,  2.0f,  1.5f,  -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
         1.5f,  2.0f, -1.5f,  -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
         1.5f, -0.5f, -1.5f,  -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
         1.5f, -0.5f, -1.5f,  -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
         1.5f, -0.5f,  1.5f,  -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
         1.5f,  2.0f,  1.5f,  -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,

        -.5f, -0.5f, -1.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
         1.5f, -0.5f, -1.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
         1.5f, -0.5f,  1.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
         1.5f, -0.5f,  1.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
        -1.5f, -0.5f,  1.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
        -1.5f, -0.5f, -1.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

        -1.5f,  2.0f, -1.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
         1.5f,  2.0f, -1.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
         1.5f,  2.0f,  1.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
         1.5f,  2.0f,  1.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
        -1.5f,  2.0f,  1.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
        -1.5f,  2.0f, -1.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
    };

    GLfloat verts3[] = {
        -4.5f, 0.0f, -4.5f,  0.0f, 1.0f,  0.0f,  0.0f,  1.0f,
         4.5f, 0.0f, -4.5f,  0.0f, 1.0f,  0.0f,  1.0f,  1.0f,
         4.5f, 0.0f,  4.5f,  0.0f, 1.0f,  0.0f,  1.0f,  0.0f,
         4.5f, 0.0f,  4.5f,  0.0f, 1.0f,  0.0f,  1.0f,  0.0f,
        -4.5f, 0.0f,  4.5f,  0.0f, 1.0f,  0.0f,  0.0f,  0.0f,
        -4.5f, 0.0f, -4.5f,  0.0f, 1.0f,  0.0f,  0.0f,  1.0f,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    // triangle
    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create VBO
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);


    // cube
    mesh.nVertices2 = sizeof(verts2) / (sizeof(verts2[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao2); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao2);

    // Create VBO
    glGenBuffers(1, &mesh.vbo2);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo2); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts2), verts2, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);



    // plane

    // cube
    mesh.nVertices3 = sizeof(verts3) / (sizeof(verts3[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao3); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao3);

    // Create VBO
    glGenBuffers(1, &mesh.vbo3);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo3); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts3), verts3, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);





    // call sphere
    //Sphere();

#define PI 3.141592654
#define TWOPI 6.283185308

    int x;
    int index = 0;


    float v1x, v1y, v1z;
    float v2x, v2y, v2z;
    float d;
    float M_PI = 3.141592654;
    int theta, phi;

    int r = 3;

    float theta0, theta1;
    float phi0, phi1;

    Vertex quad[4];

    Vertex* sphereData = (Vertex*)malloc(128 * 256 * 6 * sizeof(Vertex));

    float delta = M_PI / 128;

    // 32 vertical segments
    for (theta = 0; theta < 128; theta++)
    {
        theta0 = theta * delta;
        theta1 = (theta + 1) * delta;

        // 64 horizontal segments
        for (phi = 0; phi < 256; phi++)
        {
            phi0 = phi * delta;
            phi1 = (phi + 1) * delta;

            // Generate 4 points per quad
            quad[0].x = r * sin(theta0) * cos(phi0);
            quad[0].y = r * cos(theta0);
            quad[0].z = r * sin(theta0) * sin(phi0);
            quad[0].u = (float)theta / (float)128;
            quad[0].v = (float)phi / (float)256;

            quad[1].x = r * sin(theta0) * cos(phi1);
            quad[1].y = r * cos(theta0);
            quad[1].z = r * sin(theta0) * sin(phi1);
            quad[1].u = (float)theta / (float)128;
            quad[1].v = (float)(phi + 1) / (float)256;

            quad[2].x = r * sin(theta1) * cos(phi1);
            quad[2].y = r * cos(theta1);
            quad[2].z = r * sin(theta1) * sin(phi1);
            quad[2].u = (float)(theta + 1) / (float)128;
            quad[2].v = (float)(phi + 1) / (float)256;

            quad[3].x = r * sin(theta1) * cos(phi0);
            quad[3].y = r * cos(theta1);
            quad[3].z = r * sin(theta1) * sin(phi0);
            quad[3].u = (float)(theta + 1) / (float)128;
            quad[3].v = (float)phi / (float)256;

            // Generate the normal
            if (theta >= 4)
            {
                v1x = quad[1].x - quad[0].x;
                v1y = quad[1].y - quad[0].y;
                v1z = quad[1].z - quad[0].z;

                v2x = quad[3].x - quad[0].x;
                v2y = quad[3].y - quad[0].y;
                v2z = quad[3].z - quad[0].z;
            }
            else
            {
                v1x = quad[0].x - quad[3].x;
                v1y = quad[0].y - quad[3].y;
                v1z = quad[0].z - quad[3].z;

                v2x = quad[2].x - quad[3].x;
                v2y = quad[2].y - quad[3].y;
                v2z = quad[2].z - quad[3].z;
            }

            quad[0].nx = (v1y * v2z) - (v2y * v1z);
            quad[0].ny = (v1z * v2x) - (v2z * v1x);
            quad[0].nz = (v1x * v2y) - (v2x * v1y);

            d = 1.0f / sqrt(quad[0].nx * quad[0].nx +
                quad[0].ny * quad[0].ny +
                quad[0].nz * quad[0].nz);

            quad[0].nx *= d;
            quad[0].ny *= d;
            quad[0].nz *= d;


            // Generate the color
            if ((theta ^ phi) & 1)
            {
                quad[0].r = 1.0f;
                quad[0].g = 1.0f;
                quad[0].b = 1.0f;
                quad[0].a = 0.0f;
            }
            else
            {
                quad[0].r = 1.0f;
                quad[0].g = 0.0f;
                quad[0].b = 0.0f;
                quad[0].a = 0.0f;
            }

            // Replicate vertex info.
            for (x = 1; x < 4; x++)
            {
                quad[x].nx = quad[0].nx;
                quad[x].ny = quad[0].ny;
                quad[x].nz = quad[0].nz;
                quad[x].r = quad[0].r;
                quad[x].g = quad[0].g;
                quad[x].b = quad[0].b;
                quad[x].a = quad[0].a;

            }
            // Store the vertices in two triangles. We are drawing everything as triangles.
            sphereData[index++] = quad[0];
            sphereData[index++] = quad[1];
            sphereData[index++] = quad[2];

            sphereData[index++] = quad[0];
            sphereData[index++] = quad[3];
            sphereData[index++] = quad[2];

        }
    }





    // Create the VAO
    glGenVertexArrays(1, &mesh.vao4);
    glBindVertexArray(mesh.vao4);

    // Create a VBO buffer
    glGenBuffers(1, &mesh.vbo4);
   
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo4);

    glBufferData(GL_ARRAY_BUFFER, 128 * 256 * 6 * sizeof(Vertex), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, 128 * 256 * 6 * sizeof(Vertex), sphereData);

    // set the colors - left as it's great for debugging
    glEnableVertexAttribArray(ATTRIB_COLOR);
    glVertexAttribPointer(ATTRIB_COLOR, 4, GL_FLOAT, GL_TRUE, sizeof(Vertex), (GLubyte*)(uintptr_t)offsetof(Vertex, r));

    // set the normals
    glEnableVertexAttribArray(ATTRIB_NORMAL);
    glVertexAttribPointer(ATTRIB_NORMAL, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLubyte*)(uintptr_t)offsetof(Vertex, nx));

    // set the positions
    glEnableVertexAttribArray(ATTRIB_VERTEX);
    glVertexAttribPointer(ATTRIB_VERTEX, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLubyte*)(uintptr_t)offsetof(Vertex, x));


    /*BindVertexArray(triangleVAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO2);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(1);*/


    //We need to free as we used malloc
    free(sphereData);
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, &mesh.vbo);
    glDeleteVertexArrays(1, &mesh.vao2);
    glDeleteBuffers(2, &mesh.vbo2);
    glDeleteVertexArrays(1, &mesh.vao3);
    glDeleteBuffers(2, &mesh.vbo3);
    glDeleteVertexArrays(1, &mesh.vao4);
    glDeleteBuffers(2, &mesh.vbo4);
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const* path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

